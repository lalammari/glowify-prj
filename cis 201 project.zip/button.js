const cart = {
    total: 0,
    add: function(price) {
      this.total += price; 
    },
  };
  function addItem(product, price) {
    cart.add(price); 
    document.getElementById('totalPrice').innerText = `Total: $${cart.total}`; 
    alert(`${product} added to cart!`);
  }


